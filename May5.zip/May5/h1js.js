// Get the search input and button
const searchInput = document.querySelector('#search input[type="text"]');
const searchButton = document.querySelector('#search button');

// Add event listener to search button
searchButton.addEventListener('click', function() {
	const searchTerm = searchInput.value.trim().toLowerCase();

	// Get all email subjects
	const emailSubjects = document.querySelectorAll('#emails .subject');

	// Loop through all email subjects and hide/show them based on search term
	for (let i = 0; i < emailSubjects.length; i++) {
		const emailSubject = emailSubjects[i];
		if (emailSubject.textContent.toLowerCase().includes(searchTerm)) {
			emailSubject.parentElement.style.display = '';
        } else {
            emailSubject.parentElement.style.display = 'none';
            }
            }
            });
            
            // Get all filter links
            const filterLinks = document.querySelectorAll('#filters a');
            
            // Add event listener to filter links
            filterLinks.forEach(function(filterLink) {
            filterLink.addEventListener('click', function(event) {
            event.preventDefault();
            	// Get the filter category
	const filterCategory = filterLink.textContent.trim();

	// Get all email list items
	const emailListItems = document.querySelectorAll('#emails li');

	// Loop through all email list items and hide/show them based on filter category
	for (let i = 0; i < emailListItems.length; i++) {
		const emailListItem = emailListItems[i];
		const emailCategory = emailListItem.getAttribute('data-category');
		if (emailCategory === filterCategory || filterCategory === 'All') {
			emailListItem.style.display = 'block';
		} else {
			emailListItem.style.display = 'none';
		}
	}
});
});