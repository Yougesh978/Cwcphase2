// Get references to the buttons and the email table
const sortByDateButton = document.querySelector('.sort-by-date');
const sortBySenderButton = document.querySelector('.sort-by-sender');
const emailTable = document.querySelector('#email-table');

// Sort the emails by date
function sortByDate() {
  const rows = Array.from(emailTable.tBodies[0].rows);
  rows.sort((a, b) => {
    const aDate = new Date(a.cells[0].textContent);
    const bDate = new Date(b.cells[0].textContent);
    return bDate - aDate;
  });
  emailTable.tBodies[0].append(...rows);
}

// Sort the emails by sender
function sortBySender() {
  const rows = Array.from(emailTable.tBodies[0].rows);
  rows.sort((a, b) => {
    const aSender = a.cells[1].textContent.toLowerCase();
    const bSender = b.cells[1].textContent.toLowerCase();
    return aSender.localeCompare(bSender);
  });
  emailTable.tBodies[0].append(...rows);
}

// Add event listeners to the buttons
sortByDateButton.addEventListener('click', sortByDate);
sortBySenderButton.addEventListener('click', sortBySender);